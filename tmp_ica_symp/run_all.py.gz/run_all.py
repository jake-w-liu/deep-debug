#!/usr/bin/env python3
"""Reproduce the numerical experiments for two ICA-SYMP 2027 short papers.

The script requires Sionna RT 2.0.1. It generates two custom triangle-mesh
scenes, executes the radio-map solver, performs all numerical studies, writes
machine-readable data, and creates the manuscript figures.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import platform
import random
import sys
import time
from dataclasses import dataclass
from heapq import heappop, heappush
from pathlib import Path
from typing import Iterable, Sequence

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from scipy.ndimage import gaussian_filter
from scipy.optimize import lsq_linear

import drjit as dr
import mitsuba as mi
import sionna.rt
from sionna.rt import PlanarArray, RadioMapSolver, RadioMaterial, Transmitter, load_scene


EPS = 1e-15


def as_numpy(value) -> np.ndarray:
    """Convert a Dr.Jit/Mitsuba tensor to a NumPy array."""
    if hasattr(value, "numpy"):
        return np.asarray(value.numpy())
    return np.asarray(value)


def ensure_dir(path: Path) -> Path:
    path.mkdir(parents=True, exist_ok=True)
    return path


def write_json(path: Path, data: object) -> None:
    path.write_text(json.dumps(data, indent=2, sort_keys=True), encoding="utf-8")


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


@dataclass(frozen=True)
class Box:
    name: str
    bounds: tuple[float, float, float, float, float, float]
    material: str
    obstacle: bool = True

    @property
    def xmin(self) -> float:
        return self.bounds[0]

    @property
    def xmax(self) -> float:
        return self.bounds[1]

    @property
    def ymin(self) -> float:
        return self.bounds[2]

    @property
    def ymax(self) -> float:
        return self.bounds[3]

    @property
    def zmin(self) -> float:
        return self.bounds[4]

    @property
    def zmax(self) -> float:
        return self.bounds[5]


def write_box_ply(path: Path, box: Box) -> None:
    """Write a closed axis-aligned box as an ASCII triangle mesh."""
    x0, x1, y0, y1, z0, z1 = box.bounds
    vertices = [
        (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0),
        (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1),
    ]
    # Counter-clockwise when viewed from outside.
    faces = [
        (0, 2, 1), (0, 3, 2),  # bottom
        (4, 5, 6), (4, 6, 7),  # top
        (0, 1, 5), (0, 5, 4),  # y-min
        (3, 7, 6), (3, 6, 2),  # y-max
        (0, 4, 7), (0, 7, 3),  # x-min
        (1, 2, 6), (1, 6, 5),  # x-max
    ]
    lines = [
        "ply", "format ascii 1.0", f"element vertex {len(vertices)}",
        "property float x", "property float y", "property float z",
        f"element face {len(faces)}", "property list uchar int vertex_indices",
        "end_header",
    ]
    lines.extend(f"{x:.9g} {y:.9g} {z:.9g}" for x, y, z in vertices)
    lines.extend(f"3 {a} {b} {c}" for a, b, c in faces)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def write_scene(scene_dir: Path, boxes: Sequence[Box]) -> Path:
    """Create a Mitsuba/Sionna XML scene and all PLY meshes."""
    mesh_dir = ensure_dir(scene_dir / "meshes")
    materials = sorted({b.material for b in boxes})
    # Placeholder ITU materials are replaced programmatically when required.
    itu_type = {
        "fixed": "concrete",
        "g1": "concrete",
        "g2": "wood",
        "g3": "glass",
        "walls": "concrete",
        "shelves": "metal",
        "floor": "concrete",
    }
    xml: list[str] = ['<scene version="2.1.0">', "", "<!-- Materials -->"]
    for material in materials:
        xml.extend([
            f'  <bsdf type="itu-radio-material" id="mat-{material}">',
            f'    <string name="type" value="{itu_type.get(material, "concrete")}"/>',
            '    <float name="thickness" value="0.15"/>',
            "  </bsdf>",
        ])
    xml.extend(["", "<!-- Triangle meshes -->"])
    for b in boxes:
        fname = f"{b.name}.ply"
        write_box_ply(mesh_dir / fname, b)
        xml.extend([
            f'  <shape type="ply" id="mesh-{b.name}">',
            f'    <string name="filename" value="meshes/{fname}"/>',
            '    <boolean name="face_normals" value="true"/>',
            f'    <ref id="mat-{b.material}" name="bsdf"/>',
            "  </shape>",
        ])
    xml.append("</scene>")
    scene_file = scene_dir / "scene.xml"
    scene_file.write_text("\n".join(xml) + "\n", encoding="utf-8")
    return scene_file


def find_scene_object(scene, token: str):
    """Find a scene object robustly despite Sionna name normalization."""
    keys = list(scene.objects.keys())
    candidates = [k for k in keys if k == token or token in k]
    if len(candidates) != 1:
        raise RuntimeError(f"Could not identify one object for token={token!r}; keys={keys}")
    return scene.objects[candidates[0]]


def set_material_for_group(scene, boxes: Sequence[Box], group: str, material: RadioMaterial) -> None:
    names = [b.name for b in boxes if b.material == group]
    if not names:
        raise RuntimeError(f"No objects for material group {group}")
    for name in names:
        find_scene_object(scene, name).radio_material = material


def configure_scene(scene, frequency_hz: float) -> None:
    scene.frequency = frequency_hz
    scene.tx_array = PlanarArray(
        num_rows=1, num_cols=1, vertical_spacing=0.5, horizontal_spacing=0.5,
        pattern="iso", polarization="V"
    )
    scene.rx_array = PlanarArray(
        num_rows=1, num_cols=1, vertical_spacing=0.5, horizontal_spacing=0.5,
        pattern="iso", polarization="V"
    )


def compute_radio_map(
    scene,
    center: Sequence[float],
    size: Sequence[float],
    cell_size: float,
    samples_per_tx: int,
    seed: int,
    max_depth: int = 3,
) -> tuple[np.ndarray, np.ndarray]:
    solver = RadioMapSolver()
    rm = solver(
        scene=scene,
        center=center,
        orientation=(0.0, 0.0, 0.0),
        size=size,
        cell_size=(cell_size, cell_size),
        samples_per_tx=int(samples_per_tx),
        max_depth=max_depth,
        los=True,
        specular_reflection=True,
        diffuse_reflection=False,
        refraction=True,
        diffraction=False,
        edge_diffraction=False,
        seed=int(seed),
    )
    pg = as_numpy(rm.path_gain).astype(np.float64)
    centers = as_numpy(rm.cell_centers).astype(np.float64)
    if pg.ndim != 3:
        raise RuntimeError(f"Unexpected path-gain shape: {pg.shape}")
    if centers.shape[-1] != 3:
        raise RuntimeError(f"Unexpected cell-center shape: {centers.shape}")
    return pg, centers


def rss_dbm_from_path_gain(path_gain: np.ndarray, powers_dbm: Sequence[float]) -> np.ndarray:
    powers = np.asarray(powers_dbm, dtype=np.float64)[:, None, None]
    return powers + 10.0 * np.log10(np.maximum(path_gain, 1e-30))


def obstacle_mask(centers: np.ndarray, boxes: Sequence[Box], receiver_height: float,
                  clearance: float = 0.0) -> np.ndarray:
    x = centers[..., 0]
    y = centers[..., 1]
    mask = np.zeros(x.shape, dtype=bool)
    for b in boxes:
        if not b.obstacle or not (b.zmin - 1e-9 <= receiver_height <= b.zmax + 1e-9):
            continue
        mask |= (
            (x >= b.xmin - clearance) & (x <= b.xmax + clearance) &
            (y >= b.ymin - clearance) & (y <= b.ymax + clearance)
        )
    return mask


def plot_boxes(ax, boxes: Sequence[Box], *, only_obstacles: bool = True) -> None:
    from matplotlib.patches import Rectangle
    for b in boxes:
        if only_obstacles and not b.obstacle:
            continue
        if b.name == "floor":
            continue
        rect = Rectangle((b.xmin, b.ymin), b.xmax-b.xmin, b.ymax-b.ymin,
                         fill=False, linewidth=0.8)
        ax.add_patch(rect)


# ---------------------------------------------------------------------------
# Paper 1: Sensitivity-weighted D-optimal measurement selection
# ---------------------------------------------------------------------------


def paper1_boxes() -> list[Box]:
    return [
        Box("floor", (0, 12, 0, 8, -0.12, 0), "fixed", obstacle=False),
        Box("outer_left", (0, 0.15, 0, 8, 0, 3), "fixed"),
        Box("outer_right", (11.85, 12, 0, 8, 0, 3), "fixed"),
        Box("outer_bottom", (0, 12, 0, 0.15, 0, 3), "fixed"),
        Box("outer_top", (0, 12, 7.85, 8, 0, 3), "fixed"),
        Box("g1_vertical", (3.9, 4.1, 0.15, 5.5, 0, 3), "g1"),
        Box("g1_horizontal", (4.1, 7.7, 5.4, 5.6, 0, 3), "g1"),
        Box("g2_vertical", (7.9, 8.1, 2.2, 7.85, 0, 3), "g2"),
        Box("g2_horizontal", (4.1, 7.9, 2.1, 2.3, 0, 3), "g2"),
        Box("g3_screen", (5.95, 6.05, 5.6, 7.85, 0, 3), "g3"),
        Box("fixed_stub", (9.7, 9.9, 0.15, 3.7, 0, 3), "fixed"),
    ]


def build_paper1_scene(root: Path):
    boxes = paper1_boxes()
    scene_file = write_scene(ensure_dir(root / "scene"), boxes)
    scene = load_scene(str(scene_file), merge_shapes=False)
    configure_scene(scene, 3.5e9)
    tx = Transmitter(name="tx", position=(1.2, 1.0, 1.8), power_dbm=20.0)
    scene.add(tx)

    fixed = RadioMaterial("fixed-custom", thickness=0.15,
                          relative_permittivity=5.3, conductivity=0.03)
    g1 = RadioMaterial("g1-custom", thickness=0.20,
                       relative_permittivity=5.0, conductivity=0.020)
    g2 = RadioMaterial("g2-custom", thickness=0.20,
                       relative_permittivity=2.7, conductivity=0.008)
    g3 = RadioMaterial("g3-custom", thickness=0.10,
                       relative_permittivity=6.4, conductivity=0.004)
    set_material_for_group(scene, boxes, "fixed", fixed)
    set_material_for_group(scene, boxes, "g1", g1)
    set_material_for_group(scene, boxes, "g2", g2)
    set_material_for_group(scene, boxes, "g3", g3)
    return scene, boxes, [g1, g2, g3]


def set_log_scales(materials: Sequence[RadioMaterial], base_sigmas: np.ndarray,
                   theta: np.ndarray) -> None:
    for material, sigma0, t in zip(materials, base_sigmas, theta, strict=True):
        material.conductivity = float(sigma0 * math.exp(float(t)))


def greedy_d_opt(jac: np.ndarray, budget: int, prior_sd: float = 0.35,
                 noise_sd: float = 1.0) -> tuple[list[int], list[float]]:
    """Greedy Bayesian D-optimal selection using the determinant lemma."""
    p = jac.shape[1]
    information = np.eye(p) / (prior_sd**2)
    remaining = set(range(jac.shape[0]))
    selected: list[int] = []
    logdets: list[float] = []
    for _ in range(budget):
        inv_info = np.linalg.inv(information)
        best_idx = None
        best_gain = -np.inf
        for idx in remaining:
            v = jac[idx] / noise_sd
            gain = math.log1p(float(v @ inv_info @ v))
            if gain > best_gain:
                best_gain = gain
                best_idx = idx
        if best_idx is None:
            raise RuntimeError("D-optimal selection exhausted candidates")
        v = jac[best_idx] / noise_sd
        information += np.outer(v, v)
        selected.append(best_idx)
        remaining.remove(best_idx)
        sign, logdet = np.linalg.slogdet(information)
        if sign <= 0:
            raise RuntimeError("Non-positive information determinant")
        logdets.append(float(logdet))
    return selected, logdets


def maximin_spatial(points: np.ndarray, nominal_rss: np.ndarray, budget: int) -> list[int]:
    selected = [int(np.argmax(nominal_rss))]
    dist_min = np.linalg.norm(points - points[selected[0]], axis=1)
    dist_min[selected[0]] = -np.inf
    while len(selected) < budget:
        idx = int(np.argmax(dist_min))
        selected.append(idx)
        d = np.linalg.norm(points - points[idx], axis=1)
        dist_min = np.minimum(dist_min, d)
        dist_min[selected] = -np.inf
    return selected


def estimate_local_parameters(jac: np.ndarray, residual: np.ndarray,
                              prior_sd: float = 0.35, noise_sd: float = 1.0) -> np.ndarray:
    p = jac.shape[1]
    A = np.vstack([jac / noise_sd, np.eye(p) / prior_sd])
    b = np.concatenate([residual / noise_sd, np.zeros(p)])
    result = lsq_linear(A, b, bounds=(-0.5, 0.5), lsmr_tol="auto", verbose=0)
    if not result.success:
        raise RuntimeError(f"Bounded least-squares failure: {result.message}")
    return result.x


def summarize_trials(df: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for (method, budget), g in df.groupby(["method", "budget"], sort=False):
        row = {"method": method, "budget": int(budget)}
        for metric in ["parameter_error_pct", "map_rmse_db"]:
            values = g[metric].to_numpy()
            row[f"{metric}_median"] = float(np.median(values))
            row[f"{metric}_q25"] = float(np.quantile(values, 0.25))
            row[f"{metric}_q75"] = float(np.quantile(values, 0.75))
        rows.append(row)
    return pd.DataFrame(rows)


def run_paper1(out_root: Path, samples_per_tx: int) -> dict:
    root = ensure_dir(out_root / "paper1_active_sampling")
    fig_dir = ensure_dir(root / "figures")
    data_dir = ensure_dir(root / "data")
    scene, boxes, materials = build_paper1_scene(root)
    base_sigmas = np.array([0.020, 0.008, 0.004], dtype=float)
    theta0 = np.zeros(3)
    map_kwargs = dict(center=(6.0, 4.0, 1.2), size=(12.0, 8.0), cell_size=0.5,
                      samples_per_tx=samples_per_tx, seed=923, max_depth=3)

    print("[paper1] nominal Sionna RT map", flush=True)
    set_log_scales(materials, base_sigmas, theta0)
    pg0, centers = compute_radio_map(scene, **map_kwargs)
    rss0 = rss_dbm_from_path_gain(pg0, [20.0])[0]

    delta = 0.22
    rss_plus = []
    rss_minus = []
    for k in range(3):
        print(f"[paper1] sensitivity pair {k+1}/3", flush=True)
        t = np.zeros(3); t[k] = delta
        set_log_scales(materials, base_sigmas, t)
        pg, _ = compute_radio_map(scene, **map_kwargs)
        rss_plus.append(rss_dbm_from_path_gain(pg, [20.0])[0])
        t[k] = -delta
        set_log_scales(materials, base_sigmas, t)
        pg, _ = compute_radio_map(scene, **map_kwargs)
        rss_minus.append(rss_dbm_from_path_gain(pg, [20.0])[0])
    set_log_scales(materials, base_sigmas, theta0)
    jac_maps = np.stack([(p-m)/(2*delta) for p, m in zip(rss_plus, rss_minus, strict=True)], axis=-1)

    obs_mask = obstacle_mask(centers, boxes, 1.2, clearance=0.05)
    valid = (~obs_mask) & np.isfinite(rss0) & (rss0 > -115.0) & np.all(np.isfinite(jac_maps), axis=-1)
    # Require a non-negligible total sensitivity to avoid information-free cells.
    valid &= np.linalg.norm(jac_maps, axis=-1) > 0.03
    if valid.sum() < 40:
        raise RuntimeError(f"Too few paper-1 candidate cells: {valid.sum()}")
    flat_idx = np.flatnonzero(valid.ravel())
    candidate_points = centers.reshape(-1, 3)[flat_idx, :2]
    candidate_rss = rss0.ravel()[flat_idx]
    candidate_jac = jac_maps.reshape(-1, 3)[flat_idx]

    budgets = [4, 6, 8, 10, 12, 16]
    max_budget = max(budgets)
    dopt_order, logdets = greedy_d_opt(candidate_jac, max_budget)
    spatial_order = maximin_spatial(candidate_points, candidate_rss, max_budget)
    strongest_order = list(np.argsort(candidate_rss)[::-1][:max_budget].astype(int))
    if len(set(dopt_order)) != max_budget:
        raise AssertionError("D-optimal selections are not unique")
    if np.any(np.diff(logdets) < -1e-10):
        raise AssertionError("D-optimal information log-determinant decreased")

    rng = np.random.default_rng(20270831)
    n_truth = 24
    true_thetas = rng.uniform(-0.24, 0.24, size=(n_truth, 3))
    true_maps = []
    for i, theta in enumerate(true_thetas):
        print(f"[paper1] nonlinear validation map {i+1}/{n_truth}", flush=True)
        set_log_scales(materials, base_sigmas, theta)
        pg, _ = compute_radio_map(scene, **map_kwargs)
        true_maps.append(rss_dbm_from_path_gain(pg, [20.0])[0])
    set_log_scales(materials, base_sigmas, theta0)
    true_maps_arr = np.stack(true_maps)

    records: list[dict] = []
    random_subsets = {
        b: [rng.choice(len(flat_idx), size=b, replace=False).astype(int).tolist() for _ in range(18)]
        for b in budgets
    }
    method_orders = {
        "Sensitivity D-opt": dopt_order,
        "Spatial maximin": spatial_order,
        "Strongest RSS": strongest_order,
    }
    n_noise = 6
    for budget in budgets:
        selections: list[tuple[str, list[int], int]] = []
        for name, order in method_orders.items():
            selections.append((name, order[:budget], 0))
        for ridx, selection in enumerate(random_subsets[budget]):
            selections.append(("Random", selection, ridx))
        for name, selection, replicate_selection in selections:
            s_global = flat_idx[np.asarray(selection, dtype=int)]
            J_s = candidate_jac[np.asarray(selection, dtype=int)]
            for truth_id, (theta_true, map_true) in enumerate(zip(true_thetas, true_maps_arr, strict=True)):
                y_true = map_true.ravel()[s_global]
                for noise_id in range(n_noise):
                    noise = rng.normal(0.0, 1.0, size=budget)
                    y = y_true + noise
                    theta_hat = estimate_local_parameters(J_s, y - rss0.ravel()[s_global])
                    scale_true = np.exp(theta_true)
                    scale_hat = np.exp(theta_hat)
                    param_error = 100.0 * np.linalg.norm(scale_hat-scale_true) / np.linalg.norm(scale_true)
                    map_pred = rss0 + np.tensordot(jac_maps, theta_hat, axes=([-1], [0]))
                    map_rmse = float(np.sqrt(np.mean((map_pred[valid] - map_true[valid])**2)))
                    records.append({
                        "method": name,
                        "budget": budget,
                        "selection_replicate": replicate_selection,
                        "truth_id": truth_id,
                        "noise_id": noise_id,
                        "parameter_error_pct": float(param_error),
                        "map_rmse_db": map_rmse,
                    })
    trials = pd.DataFrame.from_records(records)
    summary = summarize_trials(trials)
    trials.to_csv(data_dir / "trials.csv", index=False)
    summary.to_csv(data_dir / "summary.csv", index=False)

    np.savez_compressed(
        data_dir / "sionna_maps_and_sensitivities.npz",
        nominal_rss_dbm=rss0,
        cell_centers_m=centers,
        valid_mask=valid,
        obstacle_mask=obs_mask,
        jacobian_db_per_log_scale=jac_maps,
        true_log_scales=true_thetas,
        true_rss_maps_dbm=true_maps_arr,
        dopt_candidate_indices=np.asarray(dopt_order),
        candidate_flat_indices=flat_idx,
        base_conductivities_s_per_m=base_sigmas,
    )

    # Figure 1: scene, selected measurements, sensitivity norm.
    extent = [centers[0, 0, 0]-0.25, centers[0, -1, 0]+0.25,
              centers[0, 0, 1]-0.25, centers[-1, 0, 1]+0.25]
    fig, axes = plt.subplots(1, 3, figsize=(7.16, 2.35), constrained_layout=True)
    im = axes[0].imshow(rss0, origin="lower", extent=extent, aspect="equal")
    plot_boxes(axes[0], boxes)
    axes[0].plot(1.2, 1.0, marker="*", markersize=7, label="TX")
    axes[0].set_title("(a) Nominal RSS (dBm)")
    axes[0].set_xlabel("x (m)"); axes[0].set_ylabel("y (m)")
    fig.colorbar(im, ax=axes[0], fraction=0.046, pad=0.02)

    axes[1].imshow(rss0, origin="lower", extent=extent, aspect="equal")
    plot_boxes(axes[1], boxes)
    sel_pts = candidate_points[np.asarray(dopt_order[:12])]
    axes[1].scatter(sel_pts[:, 0], sel_pts[:, 1], s=16, marker="o", label="selected")
    axes[1].plot(1.2, 1.0, marker="*", markersize=7)
    for i, (x, y) in enumerate(sel_pts, start=1):
        axes[1].text(x+0.08, y+0.05, str(i), fontsize=5)
    axes[1].set_title("(b) D-optimal locations")
    axes[1].set_xlabel("x (m)"); axes[1].set_yticks([])

    sens_norm = np.linalg.norm(jac_maps, axis=-1)
    sens_plot = np.where(valid, sens_norm, np.nan)
    im2 = axes[2].imshow(sens_plot, origin="lower", extent=extent, aspect="equal")
    plot_boxes(axes[2], boxes)
    axes[2].set_title("(c) RSS sensitivity norm")
    axes[2].set_xlabel("x (m)"); axes[2].set_yticks([])
    fig.colorbar(im2, ax=axes[2], fraction=0.046, pad=0.02)
    for ext in ["png", "pdf"]:
        fig.savefig(fig_dir / f"scene_selection_sensitivity.{ext}", dpi=300)
    plt.close(fig)

    # Figure 2: numerical performance.
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.35), constrained_layout=True)
    method_order = ["Random", "Spatial maximin", "Strongest RSS", "Sensitivity D-opt"]
    for method in method_order:
        g = summary[summary.method == method].sort_values("budget")
        x = g.budget.to_numpy()
        med = g.parameter_error_pct_median.to_numpy()
        lo = g.parameter_error_pct_q25.to_numpy(); hi = g.parameter_error_pct_q75.to_numpy()
        line, = axes[0].plot(x, med, marker="o", linewidth=1.2, label=method)
        axes[0].fill_between(x, lo, hi, alpha=0.13, color=line.get_color())
        med = g.map_rmse_db_median.to_numpy()
        lo = g.map_rmse_db_q25.to_numpy(); hi = g.map_rmse_db_q75.to_numpy()
        line2, = axes[1].plot(x, med, marker="o", linewidth=1.2, label=method)
        axes[1].fill_between(x, lo, hi, alpha=0.13, color=line2.get_color())
    axes[0].set_title("(a) Material-scale recovery")
    axes[0].set_xlabel("Number of measurements"); axes[0].set_ylabel("Relative error (%)")
    axes[0].grid(True, linewidth=0.3, alpha=0.5)
    axes[1].set_title("(b) Reconstructed radio map")
    axes[1].set_xlabel("Number of measurements"); axes[1].set_ylabel("RMSE (dB)")
    axes[1].grid(True, linewidth=0.3, alpha=0.5)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=4, bbox_to_anchor=(0.5, -0.05), fontsize=7)
    for ext in ["png", "pdf"]:
        fig.savefig(fig_dir / f"calibration_performance.{ext}", dpi=300, bbox_inches="tight")
    plt.close(fig)

    # Extract a few manuscript-facing numbers from executed data.
    d12 = summary[(summary.method == "Sensitivity D-opt") & (summary.budget == 12)].iloc[0]
    r12 = summary[(summary.method == "Random") & (summary.budget == 12)].iloc[0]
    s12 = summary[(summary.method == "Strongest RSS") & (summary.budget == 12)].iloc[0]
    metrics = {
        "candidate_cells": int(valid.sum()),
        "nonlinear_truth_maps": int(n_truth),
        "noise_realizations_per_truth": int(n_noise),
        "samples_per_tx": int(samples_per_tx),
        "dopt_12_parameter_error_median_pct": float(d12.parameter_error_pct_median),
        "random_12_parameter_error_median_pct": float(r12.parameter_error_pct_median),
        "strongest_12_parameter_error_median_pct": float(s12.parameter_error_pct_median),
        "dopt_12_map_rmse_median_db": float(d12.map_rmse_db_median),
        "random_12_map_rmse_median_db": float(r12.map_rmse_db_median),
        "parameter_error_reduction_vs_random_pct": float(
            100*(r12.parameter_error_pct_median-d12.parameter_error_pct_median)/r12.parameter_error_pct_median
        ),
        "map_rmse_reduction_vs_random_pct": float(
            100*(r12.map_rmse_db_median-d12.map_rmse_db_median)/r12.map_rmse_db_median
        ),
    }
    write_json(data_dir / "metrics.json", metrics)
    return metrics


# ---------------------------------------------------------------------------
# Paper 2: Length-budgeted outage-run planning
# ---------------------------------------------------------------------------


def paper2_boxes() -> list[Box]:
    boxes = [
        Box("floor", (0, 18, 0, 12, -0.12, 0), "floor", obstacle=False),
        Box("wall_left", (0, 0.18, 0, 12, 0, 3.5), "walls"),
        Box("wall_right", (17.82, 18, 0, 12, 0, 3.5), "walls"),
        Box("wall_bottom", (0, 18, 0, 0.18, 0, 3.5), "walls"),
        Box("wall_top", (0, 18, 11.82, 12, 0, 3.5), "walls"),
        Box("shelf_a", (3.0, 6.0, 3.0, 4.0, 0, 2.4), "shelves"),
        Box("shelf_b", (3.0, 6.0, 6.3, 7.3, 0, 2.4), "shelves"),
        Box("shelf_c", (8.0, 10.0, 1.8, 5.0, 0, 2.4), "shelves"),
        Box("shelf_d", (8.0, 10.0, 7.0, 10.2, 0, 2.4), "shelves"),
        Box("shelf_e", (12.0, 15.2, 4.5, 5.5, 0, 2.4), "shelves"),
        Box("shelf_f", (12.0, 15.2, 8.0, 9.0, 0, 2.4), "shelves"),
    ]
    return boxes


def build_paper2_scene(root: Path):
    boxes = paper2_boxes()
    scene_file = write_scene(ensure_dir(root / "scene"), boxes)
    scene = load_scene(str(scene_file), merge_shapes=False)
    configure_scene(scene, 3.5e9)
    scene.add(Transmitter(name="ap-left", position=(1.2, 10.6, 2.8), power_dbm=20.0))
    scene.add(Transmitter(name="ap-right", position=(16.8, 10.6, 2.8), power_dbm=20.0))
    floor = RadioMaterial("floor-custom", thickness=0.15,
                          relative_permittivity=5.3, conductivity=0.03)
    walls = RadioMaterial("walls-custom", thickness=0.18,
                          relative_permittivity=5.3, conductivity=0.03)
    shelves = RadioMaterial("shelves-custom", thickness=0.08,
                            relative_permittivity=4.5, conductivity=0.06)
    set_material_for_group(scene, boxes, "floor", floor)
    set_material_for_group(scene, boxes, "walls", walls)
    set_material_for_group(scene, boxes, "shelves", shelves)
    return scene, boxes, walls, shelves


def neighbors4(node: tuple[int, int], shape: tuple[int, int], free: np.ndarray) -> Iterable[tuple[int, int]]:
    y, x = node
    ny, nx_ = shape
    for dy, dx in ((-1, 0), (1, 0), (0, -1), (0, 1)):
        yy, xx = y+dy, x+dx
        if 0 <= yy < ny and 0 <= xx < nx_ and free[yy, xx]:
            yield yy, xx


def shortest_path_weighted(free: np.ndarray, start: tuple[int, int], goal: tuple[int, int],
                           node_penalty: np.ndarray | None = None,
                           penalty_weight: float = 0.0) -> list[tuple[int, int]]:
    """Dijkstra on a 4-neighbor grid with positive destination-node penalties."""
    dist = {start: 0.0}
    pred: dict[tuple[int, int], tuple[int, int]] = {}
    heap = [(0.0, start)]
    while heap:
        d, u = heappop(heap)
        if d != dist.get(u):
            continue
        if u == goal:
            break
        for v in neighbors4(u, free.shape, free):
            w = 1.0
            if node_penalty is not None:
                w += penalty_weight * float(node_penalty[v])
            nd = d + w
            if nd < dist.get(v, np.inf):
                dist[v] = nd; pred[v] = u; heappush(heap, (nd, v))
    if goal not in dist:
        raise RuntimeError("No path between start and goal")
    path = [goal]
    while path[-1] != start:
        path.append(pred[path[-1]])
    path.reverse()
    return path


def shortest_with_run_bound(free: np.ndarray, outage: np.ndarray,
                            start: tuple[int, int], goal: tuple[int, int],
                            max_run_cells: int) -> list[tuple[int, int]] | None:
    """Exact shortest path on the expanded finite state (cell,current run)."""
    r0 = 1 if outage[start] else 0
    if r0 > max_run_cells:
        return None
    s0 = (start[0], start[1], r0)
    dist = {s0: 0}
    pred: dict[tuple[int, int, int], tuple[int, int, int]] = {}
    heap = [(0, s0)]
    goal_state = None
    while heap:
        d, state = heappop(heap)
        if d != dist.get(state):
            continue
        y, x, run = state
        if (y, x) == goal:
            goal_state = state
            break
        for yy, xx in neighbors4((y, x), free.shape, free):
            new_run = run + 1 if outage[yy, xx] else 0
            if new_run > max_run_cells:
                continue
            nxt = (yy, xx, new_run)
            nd = d + 1
            if nd < dist.get(nxt, np.inf):
                dist[nxt] = nd; pred[nxt] = state; heappush(heap, (nd, nxt))
    if goal_state is None:
        return None
    states = [goal_state]
    while states[-1] != s0:
        states.append(pred[states[-1]])
    states.reverse()
    return [(y, x) for y, x, _ in states]


def max_outage_run_cells(path: Sequence[tuple[int, int]], rss: np.ndarray, threshold: float) -> int:
    best = 0; current = 0
    for node in path:
        if rss[node] < threshold:
            current += 1; best = max(best, current)
        else:
            current = 0
    return best


def outage_fraction(path: Sequence[tuple[int, int]], rss: np.ndarray, threshold: float) -> float:
    return float(np.mean([rss[node] < threshold for node in path]))


def nearest_free(centers: np.ndarray, free: np.ndarray, point: tuple[float, float]) -> tuple[int, int]:
    d2 = (centers[..., 0]-point[0])**2 + (centers[..., 1]-point[1])**2
    d2 = np.where(free, d2, np.inf)
    idx = int(np.argmin(d2))
    return np.unravel_index(idx, free.shape)


def optimize_run_path(free: np.ndarray, outage: np.ndarray,
                      start: tuple[int, int], goal: tuple[int, int],
                      length_budget_cells: int) -> tuple[list[tuple[int, int]], int]:
    for k in range(0, length_budget_cells + 2):
        path = shortest_with_run_bound(free, outage, start, goal, k)
        if path is not None and len(path)-1 <= length_budget_cells:
            return path, k
    raise RuntimeError("No length-budgeted run-constrained path")


def exhaustive_small_graph_check() -> None:
    """Verify expanded-state run planning against exhaustive simple paths."""
    free = np.ones((3, 4), dtype=bool)
    free[1, 1] = False
    outage = np.array([
        [False, True, True, False],
        [False, False, True, False],
        [True, True, False, False],
    ], dtype=bool)
    start, goal = (0, 0), (0, 3)
    graph = nx.Graph()
    for y in range(3):
        for x in range(4):
            if not free[y, x]:
                continue
            for v in neighbors4((y, x), free.shape, free):
                graph.add_edge((y, x), v)
    for k in range(0, 5):
        algo = shortest_with_run_bound(free, outage, start, goal, k)
        feasible_lengths = []
        for path in nx.all_simple_paths(graph, start, goal):
            run = 0; max_run = 0
            for node in path:
                if outage[node]:
                    run += 1; max_run = max(max_run, run)
                else:
                    run = 0
            if max_run <= k:
                feasible_lengths.append(len(path)-1)
        if not feasible_lengths:
            assert algo is None
        else:
            assert algo is not None
            assert len(algo)-1 == min(feasible_lengths)


def run_paper2(out_root: Path, samples_per_tx: int) -> dict:
    root = ensure_dir(out_root / "paper2_radio_navigation")
    fig_dir = ensure_dir(root / "figures")
    data_dir = ensure_dir(root / "data")
    scene, boxes, walls, shelves = build_paper2_scene(root)
    base_wall_sigma = 0.03
    base_shelf_sigma = 0.06
    map_kwargs = dict(center=(9.0, 6.0, 1.0), size=(18.0, 12.0), cell_size=0.5,
                      samples_per_tx=samples_per_tx, seed=1729, max_depth=3)

    print("[paper2] nominal Sionna RT map", flush=True)
    walls.conductivity = base_wall_sigma
    shelves.conductivity = base_shelf_sigma
    pg0, centers = compute_radio_map(scene, **map_kwargs)
    rss0_tx = rss_dbm_from_path_gain(pg0, [20.0, 20.0])
    delta = 0.24
    derivatives = []
    for label, material, base in [("walls", walls, base_wall_sigma), ("shelves", shelves, base_shelf_sigma)]:
        print(f"[paper2] {label} sensitivity pair", flush=True)
        material.conductivity = base * math.exp(delta)
        pgp, _ = compute_radio_map(scene, **map_kwargs)
        rp = rss_dbm_from_path_gain(pgp, [20.0, 20.0])
        material.conductivity = base * math.exp(-delta)
        pgm, _ = compute_radio_map(scene, **map_kwargs)
        rm = rss_dbm_from_path_gain(pgm, [20.0, 20.0])
        material.conductivity = base
        derivatives.append((rp-rm)/(2*delta))
    drss_wall, drss_shelf = derivatives

    obs = obstacle_mask(centers, boxes, receiver_height=1.0, clearance=0.28)
    free = ~obs
    # Remove cells with no valid ray-traced result for either AP.
    free &= np.any(np.isfinite(rss0_tx) & (rss0_tx > -140), axis=0)
    start = nearest_free(centers, free, (1.0, 1.0))
    goal = nearest_free(centers, free, (17.0, 1.0))
    shortest = shortest_path_weighted(free, start, goal)
    shortest_cells = len(shortest)-1
    length_budget_cells = int(math.ceil(1.10 * shortest_cells))

    rng = np.random.default_rng(20270901)
    n_train, n_test = 120, 300
    ny, nx_ = free.shape

    def correlated_field(std_db: float, corr_m: float) -> np.ndarray:
        raw = rng.normal(size=(ny, nx_))
        sigma_cells = max(corr_m / 0.5, 0.5)
        field = gaussian_filter(raw, sigma=sigma_cells, mode="reflect")
        field -= np.mean(field[free])
        scale = np.std(field[free])
        if scale < 1e-12:
            raise RuntimeError("Degenerate correlated field")
        return field * (std_db / scale)

    def sample_map() -> np.ndarray:
        tw = float(np.clip(rng.normal(0, 0.20), -0.5, 0.5))
        ts = float(np.clip(rng.normal(0, 0.25), -0.6, 0.6))
        power_bias = rng.normal(0.0, 1.0, size=(2, 1, 1))
        common = correlated_field(1.5, 1.7)[None, ...]
        independent = np.stack([correlated_field(1.0, 1.0), correlated_field(1.0, 1.0)])
        tx_maps = rss0_tx + drss_wall*tw + drss_shelf*ts + power_bias + common + independent
        return np.max(tx_maps, axis=0)

    ensemble = np.stack([sample_map() for _ in range(n_train+n_test)])
    train_maps = ensemble[:n_train]
    test_maps = ensemble[n_train:]
    robust_map = np.quantile(train_maps, 0.10, axis=0)
    nominal_best = np.max(rss0_tx, axis=0)
    threshold = float(np.quantile(robust_map[free], 0.34))
    robust_outage = robust_map < threshold

    proposed, k_star = optimize_run_path(free, robust_outage, start, goal, length_budget_cells)

    # Additive baselines are tuned only on the training ensemble and obey the same length budget.
    lambdas = [0.05, 0.1, 0.2, 0.4, 0.8, 1.5, 3.0, 6.0]
    def choose_penalty_path(design_map: np.ndarray) -> tuple[list[tuple[int, int]], float]:
        penalty = np.maximum(0.0, threshold-design_map) / 6.0
        options = []
        for lam in lambdas:
            path = shortest_path_weighted(free, start, goal, penalty, lam)
            if len(path)-1 > length_budget_cells:
                continue
            runs = np.asarray([max_outage_run_cells(path, m, threshold) for m in train_maps])
            score = (float(np.quantile(runs, 0.90)), float(np.median(runs)), len(path)-1, lam)
            options.append((score, path, lam))
        if not options:
            return shortest, 0.0
        options.sort(key=lambda z: z[0])
        return options[0][1], float(options[0][2])

    nominal_penalty, lambda_nominal = choose_penalty_path(nominal_best)
    robust_penalty, lambda_robust = choose_penalty_path(robust_map)
    methods = {
        "Distance": shortest,
        "Nominal penalty": nominal_penalty,
        "Robust penalty": robust_penalty,
        "Run-limited": proposed,
    }

    records = []
    for map_id, rss in enumerate(test_maps):
        for method, path in methods.items():
            records.append({
                "map_id": map_id,
                "method": method,
                "path_length_m": (len(path)-1)*0.5,
                "max_outage_run_m": max_outage_run_cells(path, rss, threshold)*0.5,
                "outage_fraction": outage_fraction(path, rss, threshold),
                "minimum_rss_dbm": float(min(rss[node] for node in path)),
            })
    trials = pd.DataFrame.from_records(records)
    rows = []
    for method, g in trials.groupby("method", sort=False):
        rows.append({
            "method": method,
            "path_length_m": float(g.path_length_m.iloc[0]),
            "max_run_m_median": float(np.median(g.max_outage_run_m)),
            "max_run_m_q90": float(np.quantile(g.max_outage_run_m, 0.90)),
            "outage_fraction_median": float(np.median(g.outage_fraction)),
            "minimum_rss_dbm_median": float(np.median(g.minimum_rss_dbm)),
        })
    summary = pd.DataFrame(rows)
    trials.to_csv(data_dir / "heldout_trials.csv", index=False)
    summary.to_csv(data_dir / "summary.csv", index=False)

    path_arrays = {name: np.array([[centers[y, x, 0], centers[y, x, 1]] for y, x in path])
                   for name, path in methods.items()}
    np.savez_compressed(
        data_dir / "sionna_maps_planning_ensemble.npz",
        nominal_per_ap_rss_dbm=rss0_tx,
        wall_sensitivity_db_per_log_scale=drss_wall,
        shelf_sensitivity_db_per_log_scale=drss_shelf,
        training_maps_dbm=train_maps,
        heldout_maps_dbm=test_maps,
        robust_map_dbm=robust_map,
        cell_centers_m=centers,
        free_mask=free,
        threshold_dbm=threshold,
        start=np.asarray(start),
        goal=np.asarray(goal),
        **{f"path_{name.lower().replace(' ', '_')}": arr for name, arr in path_arrays.items()},
    )

    extent = [centers[0, 0, 0]-0.25, centers[0, -1, 0]+0.25,
              centers[0, 0, 1]-0.25, centers[-1, 0, 1]+0.25]
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.65), constrained_layout=True)
    im = axes[0].imshow(robust_map, origin="lower", extent=extent, aspect="equal")
    plot_boxes(axes[0], boxes)
    axes[0].plot(1.2, 10.6, marker="^", markersize=6)
    axes[0].plot(16.8, 10.6, marker="^", markersize=6)
    axes[0].set_title("(a) Training 10th-percentile RSS")
    axes[0].set_xlabel("x (m)"); axes[0].set_ylabel("y (m)")
    fig.colorbar(im, ax=axes[0], fraction=0.046, pad=0.02, label="dBm")

    axes[1].imshow(robust_map, origin="lower", extent=extent, aspect="equal")
    plot_boxes(axes[1], boxes)
    for method, coords in path_arrays.items():
        axes[1].plot(coords[:, 0], coords[:, 1], linewidth=1.4, label=method)
    axes[1].scatter([centers[start][0], centers[goal][0]], [centers[start][1], centers[goal][1]],
                    marker="o", s=18)
    axes[1].set_title("(b) Planned routes")
    axes[1].set_xlabel("x (m)"); axes[1].set_yticks([])
    axes[1].legend(fontsize=6, loc="upper center", ncol=2)
    for ext in ["png", "pdf"]:
        fig.savefig(fig_dir / f"environment_and_paths.{ext}", dpi=300)
    plt.close(fig)

    fig, axes = plt.subplots(1, 2, figsize=(7.16, 2.35), constrained_layout=True)
    method_order = ["Distance", "Nominal penalty", "Robust penalty", "Run-limited"]
    sorder = summary.set_index("method").loc[method_order]
    axes[0].bar(np.arange(len(method_order)), sorder.path_length_m.to_numpy())
    axes[0].axhline(length_budget_cells*0.5, linestyle="--", linewidth=0.8, label="length budget")
    axes[0].set_xticks(np.arange(len(method_order)), ["Distance", "Nominal\npenalty", "Robust\npenalty", "Run-limited"], fontsize=7)
    axes[0].set_ylabel("Path length (m)"); axes[0].set_title("(a) Route length")
    axes[0].legend(fontsize=6)
    for method in method_order:
        values = np.sort(trials.loc[trials.method == method, "max_outage_run_m"].to_numpy())
        cdf = np.arange(1, len(values)+1)/len(values)
        axes[1].step(values, cdf, where="post", label=method, linewidth=1.2)
    axes[1].set_xlabel("Maximum contiguous outage run (m)")
    axes[1].set_ylabel("Empirical CDF"); axes[1].set_title("(b) 300 held-out maps")
    axes[1].grid(True, linewidth=0.3, alpha=0.5)
    axes[1].legend(fontsize=6, loc="lower right")
    for ext in ["png", "pdf"]:
        fig.savefig(fig_dir / f"planning_performance.{ext}", dpi=300)
    plt.close(fig)

    exhaustive_small_graph_check()
    proposed_summary = sorder.loc["Run-limited"]
    distance_summary = sorder.loc["Distance"]
    robust_summary = sorder.loc["Robust penalty"]
    metrics = {
        "samples_per_tx": int(samples_per_tx),
        "training_maps": n_train,
        "heldout_maps": n_test,
        "threshold_dbm": threshold,
        "shortest_path_length_m": shortest_cells*0.5,
        "length_budget_m": length_budget_cells*0.5,
        "run_limit_cells_design": int(k_star),
        "run_limit_m_design": float(k_star*0.5),
        "selected_nominal_penalty_weight": lambda_nominal,
        "selected_robust_penalty_weight": lambda_robust,
        "proposed_path_length_m": float(proposed_summary.path_length_m),
        "proposed_q90_max_run_m": float(proposed_summary.max_run_m_q90),
        "distance_q90_max_run_m": float(distance_summary.max_run_m_q90),
        "robust_penalty_q90_max_run_m": float(robust_summary.max_run_m_q90),
        "q90_run_reduction_vs_distance_pct": float(
            100*(distance_summary.max_run_m_q90-proposed_summary.max_run_m_q90)/max(distance_summary.max_run_m_q90, EPS)
        ),
    }
    write_json(data_dir / "metrics.json", metrics)
    return metrics


def build_manifest(root: Path) -> None:
    rows = []
    for path in sorted(p for p in root.rglob("*") if p.is_file()):
        rows.append({
            "path": str(path.relative_to(root)),
            "bytes": path.stat().st_size,
            "sha256": sha256(path),
        })
    write_json(root / "artifact_manifest.json", rows)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--samples-per-tx", type=int, default=int(os.environ.get("SAMPLES_PER_TX", "750000")))
    args = parser.parse_args()
    out = ensure_dir(args.output.resolve())
    t0 = time.time()
    environment = {
        "python": sys.version,
        "platform": platform.platform(),
        "sionna_rt": getattr(sionna.rt, "__version__", "2.0.1"),
        "mitsuba": getattr(mi, "__version__", "unknown"),
        "drjit": getattr(dr, "__version__", "unknown"),
        "mitsuba_variant": mi.variant(),
        "samples_per_tx": args.samples_per_tx,
    }
    write_json(out / "environment.json", environment)
    p1 = run_paper1(out, args.samples_per_tx)
    p2 = run_paper2(out, args.samples_per_tx)
    write_json(out / "combined_metrics.json", {"paper1": p1, "paper2": p2})
    write_json(out / "run_status.json", {
        "status": "passed",
        "elapsed_seconds": time.time()-t0,
        "paper1": p1,
        "paper2": p2,
    })
    build_manifest(out)
    print(json.dumps({"paper1": p1, "paper2": p2}, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
