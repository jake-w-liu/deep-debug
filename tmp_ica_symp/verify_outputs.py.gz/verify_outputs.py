#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
import numpy as np
import pandas as pd


def require(path: Path, min_bytes: int = 1):
    if not path.is_file() or path.stat().st_size < min_bytes:
        raise SystemExit(f"missing or empty: {path}")


def main():
    p = argparse.ArgumentParser(); p.add_argument("root", type=Path); a=p.parse_args()
    root=a.root
    required = [
        root/"run_status.json", root/"combined_metrics.json", root/"environment.json",
        root/"paper1_active_sampling/data/metrics.json",
        root/"paper1_active_sampling/data/summary.csv",
        root/"paper1_active_sampling/data/trials.csv",
        root/"paper1_active_sampling/data/sionna_maps_and_sensitivities.npz",
        root/"paper1_active_sampling/figures/scene_selection_sensitivity.pdf",
        root/"paper1_active_sampling/figures/calibration_performance.pdf",
        root/"paper2_radio_navigation/data/metrics.json",
        root/"paper2_radio_navigation/data/summary.csv",
        root/"paper2_radio_navigation/data/heldout_trials.csv",
        root/"paper2_radio_navigation/data/sionna_maps_planning_ensemble.npz",
        root/"paper2_radio_navigation/figures/environment_and_paths.pdf",
        root/"paper2_radio_navigation/figures/planning_performance.pdf",
    ]
    for q in required: require(q, 20)
    status=json.loads((root/"run_status.json").read_text())
    assert status["status"]=="passed"
    p1=np.load(root/"paper1_active_sampling/data/sionna_maps_and_sensitivities.npz")
    assert p1["nominal_rss_dbm"].ndim==2
    assert p1["jacobian_db_per_log_scale"].shape[-1]==3
    assert np.isfinite(p1["jacobian_db_per_log_scale"][p1["valid_mask"]]).all()
    s1=pd.read_csv(root/"paper1_active_sampling/data/summary.csv")
    assert set(s1.method)=={"Sensitivity D-opt","Spatial maximin","Strongest RSS","Random"}
    assert set(s1.budget)=={4,6,8,10,12,16}
    p2=np.load(root/"paper2_radio_navigation/data/sionna_maps_planning_ensemble.npz")
    assert p2["heldout_maps_dbm"].shape[0]==300
    s2=pd.read_csv(root/"paper2_radio_navigation/data/summary.csv")
    assert set(s2.method)=={"Distance","Nominal penalty","Robust penalty","Run-limited"}
    assert (s2.path_length_m>0).all()
    print("verification passed")

if __name__=="__main__": main()
